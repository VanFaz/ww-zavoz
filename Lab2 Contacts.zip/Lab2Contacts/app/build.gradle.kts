plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.lab2"
    compileSdk { version = release(37) }

    defaultConfig {
        applicationId = "com.example.lab2"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel:2.6.2")
}
