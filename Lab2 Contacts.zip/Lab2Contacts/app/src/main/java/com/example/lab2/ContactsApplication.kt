package com.example.lab2

import android.app.Application
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner

// Общий владелец ViewModel, чтобы обе Activity работали с одним списком.
// Список существует только в памяти, пока работает процесс приложения.
class ContactsApplication : Application(), ViewModelStoreOwner {
    override val viewModelStore = ViewModelStore()

    val contactsViewModel: ContactsViewModel by lazy {
        ViewModelProvider(this)[ContactsViewModel::class.java]
    }
}
