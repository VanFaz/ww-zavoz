package com.example.lab2

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class EditContactActivity : AppCompatActivity() {
    private lateinit var viewModel: ContactsViewModel
    private lateinit var lastNameInput: EditText
    private lateinit var firstNameInput: EditText
    private lateinit var middleNameInput: EditText
    private lateinit var phoneInput: EditText
    private var isEditing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_contact)

        viewModel = (application as ContactsApplication).contactsViewModel
        lastNameInput = findViewById(R.id.lastNameInput)
        firstNameInput = findViewById(R.id.firstNameInput)
        middleNameInput = findViewById(R.id.middleNameInput)
        phoneInput = findViewById(R.id.phoneInput)
        isEditing = intent.getBooleanExtra("isEditing", false)

        findViewById<TextView>(R.id.editorTitle).setText(
            if (isEditing) R.string.edit_contact else R.string.add_contact
        )

        // При повороте экрана Android сам восстанавливает введённые поля.
        if (isEditing && savedInstanceState == null) {
            val contact = viewModel.currentContact()
            if (contact != null) {
                lastNameInput.setText(contact.lastName)
                firstNameInput.setText(contact.firstName)
                middleNameInput.setText(contact.middleName)
                phoneInput.setText(contact.phone)
            }
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            saveContact()
        }
    }

    private fun saveContact() {
        val lastName = lastNameInput.text.toString().trim()
        val firstName = firstNameInput.text.toString().trim()
        val middleName = middleNameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()

        // Отчество можно оставить пустым, остальные поля обязательны.
        if (lastName.isEmpty()) {
            lastNameInput.error = getString(R.string.enter_last_name)
            lastNameInput.requestFocus()
            return
        }
        if (firstName.isEmpty()) {
            firstNameInput.error = getString(R.string.enter_first_name)
            firstNameInput.requestFocus()
            return
        }
        if (phone.isEmpty()) {
            phoneInput.error = getString(R.string.enter_phone)
            phoneInput.requestFocus()
            return
        }

        val contact = Contact(lastName, firstName, middleName, phone)
        if (isEditing) {
            viewModel.updateContact(contact)
        } else {
            viewModel.addContact(contact)
        }
        finish()
    }
}
