package com.example.lab2

import androidx.lifecycle.ViewModel

class ContactsViewModel : ViewModel() {
    private val contacts = mutableListOf<Contact>()
    private var currentIndex = 0

    fun currentContact(): Contact? {
        return contacts.getOrNull(currentIndex)
    }

    fun addContact(contact: Contact) {
        contacts.add(contact)
        currentIndex = contacts.lastIndex
    }

    fun updateContact(contact: Contact) {
        if (contacts.isNotEmpty()) {
            contacts[currentIndex] = contact
        }
    }

    fun previousContact() {
        if (hasPrevious()) currentIndex--
    }

    fun nextContact() {
        if (hasNext()) currentIndex++
    }

    fun hasPrevious(): Boolean = currentIndex > 0

    fun hasNext(): Boolean = currentIndex < contacts.lastIndex
}
