package com.example.lab2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: ContactsViewModel
    private lateinit var contactText: TextView
    private lateinit var previousButton: ImageButton
    private lateinit var nextButton: ImageButton
    private lateinit var editButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = (application as ContactsApplication).contactsViewModel
        contactText = findViewById(R.id.contactText)
        previousButton = findViewById(R.id.previousButton)
        nextButton = findViewById(R.id.nextButton)
        editButton = findViewById(R.id.editButton)

        previousButton.setOnClickListener {
            viewModel.previousContact()
            showContact()
        }

        nextButton.setOnClickListener {
            viewModel.nextContact()
            showContact()
        }

        findViewById<Button>(R.id.addButton).setOnClickListener {
            openEditor(false)
        }

        editButton.setOnClickListener {
            openEditor(true)
        }
    }

    override fun onResume() {
        super.onResume()
        // После сохранения на втором экране показываем обновлённый контакт.
        showContact()
    }

    private fun openEditor(isEditing: Boolean) {
        val intent = Intent(this, EditContactActivity::class.java)
        intent.putExtra("isEditing", isEditing)
        startActivity(intent)
    }

    private fun showContact() {
        val contact = viewModel.currentContact()
        contactText.text = if (contact == null) {
            getString(R.string.empty_contacts)
        } else {
            val fullName = listOf(contact.lastName, contact.firstName, contact.middleName)
                .filter { it.isNotEmpty() }
                .joinToString(" ")
            "$fullName\n${contact.phone}"
        }

        previousButton.isEnabled = viewModel.hasPrevious()
        nextButton.isEnabled = viewModel.hasNext()
        previousButton.alpha = if (previousButton.isEnabled) 1f else 0.35f
        nextButton.alpha = if (nextButton.isEnabled) 1f else 0.35f
        editButton.isEnabled = contact != null
    }
}
