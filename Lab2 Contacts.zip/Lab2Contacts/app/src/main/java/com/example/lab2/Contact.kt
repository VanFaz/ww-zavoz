package com.example.lab2

// Одна запись в списке контактов.
data class Contact(
    val lastName: String,
    val firstName: String,
    val middleName: String,
    val phone: String
)
